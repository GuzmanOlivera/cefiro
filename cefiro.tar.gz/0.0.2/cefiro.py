# -*- coding: utf-8 -*-

from trytond.model import ModelView, ModelSQL, fields

class Psicologo(ModelSQL,ModelView):
	'Psicologo'
	_name = 'cefiro.psicologo'
	_description = __doc__
	nombre = fields.Char('Nombre')
	cedula = fields.Char('C.I.')
	pacientes = fields.One2Many('cefiro.paciente','psicologo','Pacientes')

Psicologo()


class Paciente(ModelSQL,ModelView):
	'Paciente'
	_name = 'cefiro.paciente'
	_description = __doc__
	nombre = fields.Char('Nombre')
	cedula = fields.Char('C.I.')
	psicologo = fields.Many2One('cefiro.psicologo','Psicologo')

Paciente()


