{
	'name' : 'Cefiro',
	'version' : '0.0.1',
	'author' : 'mtasende',
	'email' : 'mtasende@psico.edu.uy',
	'website' : 'www.psico.edu.uy',
	'description' : 'Programa de administración y gestión de historias clínicas para el CIC-P y SAPPA',
	'depends' : [
		'ir',
	],
	'xml' : [
		'cefiro.xml',
	],
	'translation' : [
	],
}

